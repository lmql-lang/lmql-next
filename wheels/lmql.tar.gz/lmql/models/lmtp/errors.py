class LMTPStreamError(Exception):
    pass