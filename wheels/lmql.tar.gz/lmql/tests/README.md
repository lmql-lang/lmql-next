# Current State of Unit Tests

This directory contains a set of unit tests that are of varying recency. Some tests here may no longer pass and specify outdated behavior. We should update these tests soon, to reflect the current state of the codebase and also introduce a testing framework to make it easier to run them.